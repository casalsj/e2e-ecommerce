# mop-e2e

Monitorización sintética E2E de **themopbookstore.com** sin servicio externo
(alternativa gratuita a Checkly). Corre con Playwright desde GitHub Actions en
cron y avisa por Slack si el camino crítico de compra se rompe.

No toca el código del cliente: ataca la web ya desplegada como un usuario real.

## Qué verifica

- Home carga y la navegación está presente
- El catálogo lista productos
- La ficha de producto muestra precio y botón de añadir
- **Camino crítico**: producto → añadir al carrito → abrir cesta → "Continuar
  con el pago" → **redirección al checkout de Shopify**

Se detiene en el handoff a Shopify. No completa el pago ni genera pedidos.

## Local

```bash
npm install
npx playwright install chromium
npm test            # o: npm run test:ui  (modo interactivo)
```

## CI (GitHub Actions)

Ya configurado en `.github/workflows/e2e.yml`: corre cada 15 min y se puede
lanzar a mano desde la pestaña Actions.

Para las alertas, crea un secret en el repo:

- `SLACK_WEBHOOK` → URL de un Incoming Webhook de Slack
  (Settings → Secrets and variables → Actions → New repository secret)

Si prefieres n8n en lugar de Slack, cambia la URL del `curl` en el workflow por
tu webhook de n8n; el payload JSON es el mismo.

## Ajustes habituales

- **Frecuencia**: edita el `cron` en el workflow. `*/15 * * * *` = cada 15 min.
- **Safari/WebKit**: descomenta el proyecto `webkit` en `playwright.config.js`.
- **Otra tienda**: cambia `BASE_URL` y los selectores en `tests/checkout.spec.js`.
- **Producto de prueba**: edita `PRODUCT_PATH` en `tests/checkout.spec.js`.
