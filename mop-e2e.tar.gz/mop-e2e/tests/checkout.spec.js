import { test, expect } from '@playwright/test';

/**
 * E2E sintético — themopbookstore.com (Shopify headless)
 *
 * Cubre el camino crítico de compra HASTA el checkout de Shopify y se detiene
 * ahí: el checkout es responsabilidad de Shopify, no del frontend. No se
 * completa ningún pago ni se genera ningún pedido.
 *
 * Flujo: home → colección → producto → añadir al carrito → abrir cesta →
 *        continuar con el pago → verificar redirección a Shopify.
 */

const PRODUCT_PATH = '/products/annie-leibovitz-in-wonderland';

test.describe('Flujo de compra crítico', () => {
  test('home carga y muestra navegación', async ({ page }) => {
    await page.goto('/');
    await expect(page).toHaveTitle(/MOP/i);
    await expect(page.getByRole('link', { name: /bookstore/i }).first()).toBeVisible();
  });

  test('catálogo bookstore lista productos', async ({ page }) => {
    await page.goto('/bookstore/bookstore-annie-leibovitz');
    // Debe haber al menos un enlace a una ficha de producto
    const productLinks = page.locator('a[href*="/products/"]');
    await expect(productLinks.first()).toBeVisible();
    expect(await productLinks.count()).toBeGreaterThan(0);
  });

  test('ficha de producto: precio y botón de añadir visibles', async ({ page }) => {
    await page.goto(PRODUCT_PATH);
    // El precio se renderiza como "NN.NN EUR"
    await expect(page.getByText(/\d+[.,]\d{2}\s*EUR/i).first()).toBeVisible();
    await expect(
      page.getByRole('button', { name: /añadir al carrito/i })
    ).toBeVisible();
  });

  test('camino crítico: producto → carrito → inicio de checkout', async ({ page }) => {
    await page.goto(PRODUCT_PATH);

    // 1. Leer estado inicial de la cesta (el contador va en el aria-label)
    const cartButton = page.getByRole('button', { name: /cesta/i }).first();
    const initialLabel = (await cartButton.getAttribute('aria-label')) || '';
    const initialCount = parseInt(initialLabel.match(/\((\d+)\)/)?.[1] || '0', 10);

    // 2. Añadir al carrito
    await page.getByRole('button', { name: /añadir al carrito/i }).first().click();

    // 3. El contador de la cesta debe incrementarse
    await expect(async () => {
      const label = (await cartButton.getAttribute('aria-label')) || '';
      const count = parseInt(label.match(/\((\d+)\)/)?.[1] || '0', 10);
      expect(count).toBeGreaterThan(initialCount);
    }).toPass({ timeout: 10_000 });

    // 4. Abrir el cajón de la cesta
    await cartButton.click();

    // 5. Verificar que el cajón muestra subtotal y el producto añadido
    await expect(page.getByText(/subtotal/i)).toBeVisible();
    await expect(
      page.getByText(/annie leibovitz in wonderland/i).first()
    ).toBeVisible();

    // 6. Pulsar "Continuar con el pago" y verificar redirección a Shopify.
    //    NO completamos el pago: solo confirmamos que el handoff funciona.
    const checkoutButton = page.getByRole('button', { name: /continuar con el pago/i });
    await expect(checkoutButton).toBeVisible();

    await Promise.all([
      page.waitForURL(/shopify\.com|\/checkouts?\//i, { timeout: 30_000 }),
      checkoutButton.click(),
    ]);

    // 7. Confirmar que estamos en el checkout de Shopify (no en error 4xx/5xx)
    expect(page.url()).toMatch(/shopify\.com|\/checkouts?\//i);
  });
});
